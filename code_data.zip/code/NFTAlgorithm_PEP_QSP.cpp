#include <numeric>   // For std::accumulate
#include "NFTAlgorithm.h"

// Function to calculate the Potential Expected Profit (PEP) of a user for a specific NFT
double calculatePEP(const User& user, const NFT& nft, const unordered_set<pair<User, NFT>>& S_k_x, int x) {
    double pep = 0.0;
    // Calculate the sum of average occurrences of users in S_k_x
    double sum_occurrences = 0.0;
    for (const auto& user_nft : S_k_x) {
        sum_occurrences += calculateInfluenceLikelihood(user_nft.first, user);
    }
    // Ensure the sum of occurrences does not exceed 1
    double influence_prob = min(1.0, sum_occurrences);
    // Calculate the Potential Expected Profit (PEP) of the user for the NFT
    pep = nft.getValue(x) * influence_prob;
    return pep;
}

// Function to calculate the Quantity Sum of PEP (QSP) for a specific set S_k_x and quantity x
double calculateQSP(const unordered_set<pair<User, NFT>>& S_k_x, const NFT& nft, int x) {
    // Sort the users in S_k_x based on their PEP in descending order
    vector<pair<User, NFT>> sorted_users(S_k_x.begin(), S_k_x.end());
    sort(sorted_users.begin(), sorted_users.end(), [&](const pair<User, NFT>& a, const pair<User, NFT>& b) {
        return calculatePEP(a.first, nft, S_k_x, x) > calculatePEP(b.first, nft, S_k_x, x);
    });

    // Calculate the Quantity Sum of PEP (QSP) for the top-x users in S_k_x
    double qsp = 0.0;
    for (int i = 0; i < min(x, static_cast<int>(sorted_users.size())); ++i) {
        qsp += calculatePEP(sorted_users[i].first, nft, S_k_x, x);
    }
    return qsp;
}

