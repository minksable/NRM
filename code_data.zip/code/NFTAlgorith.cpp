#include <algorithm> // For std::min
#include <numeric>   // For std::accumulate
#include <cmath>  // For std::pow

#include "NFTAlgorithm.h"
#include "Graph.h"


using namespace std;

// Function to identify treasures based on the rarest traits
set<NFT> findTreasures(const Graph& graph) {
    // Retrieve the set of rarest traits according to trait rarity
    set<string> rarest_traits;
    // Implement the logic to determine the rarest traits
    // ...

    // Identify treasures as NFTs with at least one rare trait
    set<NFT> treasures;
    for (const auto& it : graph.NFTs) {
        const set<string>& traits = it.first;
        bool has_rare_trait = false;
        for (const string& trait : traits) {
            if (rarest_traits.count(trait)) {
                has_rare_trait = true;
                break;
            }
        }
        if (has_rare_trait) {
            treasures.insert(it.second);
        }
    }
    return treasures;
}

// Function to identify users purchasing at least one treasure as nThrees
set<string> findNThrees(const Graph& graph, const set<NFT>& treasures) {
    set<string> nThrees;
    for (const auto& user : graph.users) {
        const string& user_id = user.first;
        const unordered_map<string, double>& user_owned_NFTs = graph.user_owned_NFTs[user_id];
        for (const auto& nft_entry : user_owned_NFTs) {
            const NFT& nft = nft_entry.first;
            if (treasures.count(nft)) {
                nThrees.insert(user_id);
                break;
            }
        }
    }
    return nThrees;
}

// Function to calculate the Treasure Influence (TI) for a prospective purchaser
double calculateTI(const User& prospective_purchaser, const NFT& nft, int breeding_quota, double impact, double beta_p, double beta_c, double gamma_p) {
    int num_treasures = countTreasures(prospective_purchaser, nft);
    double TI = 0.0;
    if (num_treasures < breeding_quota) {
        TI = beta_p * impact * nft.preference.at(prospective_purchaser.id);
    } else {
        for (const auto& friend_id_weight : prospective_purchaser.friends) {
            if (prospective_purchaser.friends.find(friend_id_weight.first) != prospective_purchaser.friends.end()) {
                TI = beta_c * gamma_p * nft.preference.at(prospective_purchaser.id);
                break;
            }
        }
    }
    return TI;
}

// Function to calculate the Value of Generating Influence (VOGI) for a user
double calculateVOGI(const User& user, const Graph& graph, const NFT& nft, int q_k) {
    double VOGI = 0.0;
    vector<pair<double, string>> top_valuation_users;
    for (const auto& user_id_weight : user.friends) {
        top_valuation_users.push_back({user_id_weight.second, user_id_weight.first});
    }
    sort(top_valuation_users.begin(), top_valuation_users.end(), greater<pair<double, string>>());
    int num_top_valuation_users = min(q_k, static_cast<int>(top_valuation_users.size()));
    for (int i = 0; i < num_top_valuation_users; ++i) {
        const User& prospective_purchaser = graph.users.at(top_valuation_users[i].second);
        double oc = calculateInfluenceLikelihood(user, prospective_purchaser);
        double TI = calculateTI(prospective_purchaser, nft, user.breeding_quota, user.impact, user.beta_p, user.beta_c, user.gamma_p);
        VOGI += TI * oc;
    }
    return VOGI;
}

// Function to calculate the likelihood of one user influencing another
double calculateInfluenceLikelihood(const User& user_i, const User& user) {
    double total_occurrence = 0.0;
    int num_reverse_reachable_sets = 0;
    
    // Iterate over all live-edges in user's live-edge graph
    for (const auto& friend_id_weight : user.friends) {
        const string& friend_id = friend_id_weight.first;
        double edge_probability = friend_id_weight.second; // Probability of edge existence
        
        // Check if flipping a biased random coin with probability edge_probability returns success
        if (flipCoin(edge_probability)) {
            // Increment the total occurrence count and the number of reverse reachable sets
            total_occurrence += countReverseReachableSets(user_i, friend_id);
            num_reverse_reachable_sets++;
        }
    }
    
    // Calculate the average occurrence of user_i in user's reverse reachable sets
    double average_occurrence = (num_reverse_reachable_sets > 0) ? total_occurrence / num_reverse_reachable_sets : 0.0;
    return average_occurrence;
}

// Function to flip a biased random coin
bool flipCoin(double probability) {
    // Generate a random number between 0 and 1
    double random_number = RANDOM_NUM();
    // Return true if the random number is less than the given probability, indicating success
    return (random_number < probability);
}

// Function to count the occurrences of user_i in user's reverse reachable sets
int countReverseReachableSets(const User& user_i, const string& friend_id) {
    // Implementation specific to counting reverse reachable sets
    // This could involve traversing the live-edge graph of friend_id to identify reverse reachable sets containing user_i
    // Return the count of occurrences of user_i in these sets
    // Note: This function needs to be implemented based on the provided description
    return 0; // Placeholder return value
}


// Function to calculate the Potential Expected Profit (PEP) of a user for a specific NFT
double calculatePEP(const User& user, const NFT& nft, const unordered_set<pair<User, NFT>>& S_k_x, int x) {
    double pep = 0.0;
    // Calculate the sum of average occurrences of users in S_k_x
    double sum_occurrences = accumulate(S_k_x.begin(), S_k_x.end(), 0.0, [&](double sum, const pair<User, NFT>& user_nft) {
        return sum + calculateInfluenceLikelihood(user_nft.first, user);
    });
    // Ensure the sum of occurrences does not exceed 1
    double influence_prob = min(1.0, sum_occurrences);
    // Calculate the Potential Expected Profit (PEP) of the user for the NFT
    pep = nft.getValue(x) * influence_prob;
    return pep;
}

// Function to calculate the Quantity Sum of PEP (QSP) for a specific set S_k_x and quantity x
double calculateQSP(const unordered_set<pair<User, NFT>>& S_k_x, const NFT& nft, int x) {
    // Sort the users in S_k_x based on their PEP in descending order
    vector<pair<User, NFT>> sorted_users(S_k_x.begin(), S_k_x.end());
    sort(sorted_users.begin(), sorted_users.end(), [&](const pair<User, NFT>& a, const pair<User, NFT>& b) {
        return calculatePEP(a.first, nft, S_k_x, x) > calculatePEP(b.first, nft, S_k_x, x);
    });

    // Calculate the Quantity Sum of PEP (QSP) for the top-x users in S_k_x
    double qsp = 0.0;
    for (int i = 0; i < min(x, static_cast<int>(sorted_users.size())); ++i) {
        qsp += calculatePEP(sorted_users[i].first, nft, S_k_x, x);
    }
    return qsp;
}



// Function to calculate the total transaction price TP(S,Q)
double calculateTotalTransactionPrice(const vector<pair<User, NFT>>& S, const vector<int>& Q) {
    double total_transaction_price = 0.0;
    for (size_t k = 0; k < N.size(); ++k) {
        double tp_k = 0.0;
        for (const auto& user_nft : S) {
            tp_k += user_nft.second.getValue(Q[k]); // Assuming getValue() returns the value of NFT for a given quantity
        }
        total_transaction_price += tp_k;
    }
    return total_transaction_price;
}

// Function to calculate the expected assessment of NFT offspring E[A(o^i_z,S,Q)]
double calculateExpectedOffspringAssessment(const NFT& offspring, const vector<pair<User, NFT>>& S, const vector<int>& Q) {
    // Implement the expected assessment calculation based on the breeding mechanism
    // Here, we assume a simple calculation for demonstration purposes
    double expected_assessment = offspring.getValue(1); // Assuming getValue() returns the value of offspring
    return expected_assessment;
}

// Function to calculate the total assessment of NFT offspring OS(S,Q)
double calculateTotalOffspringAssessment(const vector<pair<User, NFT>>& S, const vector<int>& Q, int breeding_quota) {
    double total_offspring_assessment = 0.0;
    for (const auto& user_nft : S) {
        for (int z = 1; z <= breeding_quota; ++z) {
            total_offspring_assessment += calculateExpectedOffspringAssessment(user_nft.second, S, Q);
        }
    }
    return total_offspring_assessment;
}

// Function to calculate the profit function f(S,Q)
double calculateProfitFunction(const vector<pair<User, NFT>>& S, const vector<int>& Q, int breeding_quota, double lambda) {
    double total_transaction_price = calculateTotalTransactionPrice(S, Q);
    double total_offspring_assessment = calculateTotalOffspringAssessment(S, Q, breeding_quota);
    double profit = total_transaction_price + lambda * total_offspring_assessment;
    return profit;
}

