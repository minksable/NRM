#pragma once
#include <bits/stdc++.h>

using namespace std;

class User{
public:
    string id;
    unordered_map<string, double> friends; // friends and their weights

    User(string s = ""){
        id = s;
    }
};