#include <algorithm> // For std::min
#include "NFTAlgorithm.h"
#include "Graph.h"

using namespace std;

// Function to calculate the Treasure Influence (TI) for a prospective purchaser
double calculateTI(const User& prospective_purchaser, const NFT& nft, int breeding_quota, double impact, double beta_p, double beta_c, double gamma_p) {
    int num_treasures = countTreasures(prospective_purchaser, nft);
    double TI = 0.0;
    if (num_treasures < breeding_quota) {
        TI = beta_p * impact * nft.preference.at(prospective_purchaser.id);
    } else {
        for (const auto& friend_id_weight : prospective_purchaser.friends) {
            if (prospective_purchaser.friends.find(friend_id_weight.first) != prospective_purchaser.friends.end()) {
                TI = beta_c * gamma_p * nft.preference.at(prospective_purchaser.id);
                break;
            }
        }
    }
    return TI;
}

// Function to calculate the Value of Generating Influence (VOGI) for a user
double calculateVOGI(const User& user, const Graph& graph, const NFT& nft, int q_k) {
    double VOGI = 0.0;
    vector<pair<double, string>> top_valuation_users;
    for (const auto& user_id_weight : user.friends) {
        top_valuation_users.push_back({user_id_weight.second, user_id_weight.first});
    }
    sort(top_valuation_users.begin(), top_valuation_users.end(), greater<pair<double, string>>());
    int num_top_valuation_users = min(q_k, static_cast<int>(top_valuation_users.size()));
    for (int i = 0; i < num_top_valuation_users; ++i) {
        const User& prospective_purchaser = graph.users.at(top_valuation_users[i].second);
        double oc = calculateInfluenceLikelihood(user, prospective_purchaser);
        double TI = calculateTI(prospective_purchaser, nft, user.breeding_quota, user.impact, user.beta_p, user.beta_c, user.gamma_p);
        VOGI += TI * oc;
    }
    return VOGI;
}

// Function to calculate the likelihood of one user influencing another
double calculateInfluenceLikelihood(const User& user_i, const User& user, const Graph& graph) {
    double total_occurrence = 0.0;
    int num_reverse_reachable_sets = 0;
    
    // Iterate over all live-edges in user's live-edge graph
    for (const auto& friend_id_weight : user.friends) {
        const string& friend_id = friend_id_weight.first;
        double edge_probability = friend_id_weight.second; // Probability of edge existence
        
        // Check if flipping a biased random coin with probability edge_probability returns success
        if (flipCoin(edge_probability)) {
            // Determine the reverse reachable sets of user_i in the deterministic realized graph of friend_id
            // You need to implement this part based on the description provided
            double oc = calculateReverseReachableSetsOccurrence(user_i, friend_id, graph);
            total_occurrence += oc;
            num_reverse_reachable_sets++;
        }
    }
    
    // Calculate the average occurrence of user_i in user's reverse reachable sets
    double average_occurrence = (num_reverse_reachable_sets > 0) ? total_occurrence / num_reverse_reachable_sets : 0.0;
    return average_occurrence;
}

// Function to count the occurrences of user_i in user's reverse reachable sets
int countReverseReachableSets(const User& user_i, const string& friend_id, const Graph& graph) {
    // Retrieve the reverse reachable sets of user_i in the deterministic realized graph of friend_id
    // You need to implement this part based on the description provided
    // This could involve traversing the live-edge graph of friend_id to identify reverse reachable sets containing user_i
    int occurrence_count = 0;
    // Placeholder logic for demonstration purposes
    // Assuming user_i is present in the reverse reachable sets of all friends
    if (graph.users.find(friend_id) != graph.users.end()) {
        const User& friend_user = graph.users.at(friend_id);
        if (friend_user.reverseReachableSets.find(user_i.id) != friend_user.reverseReachableSets.end()) {
            occurrence_count = friend_user.reverseReachableSets.at(user_i.id);
        }
    }
    return occurrence_count;
}

