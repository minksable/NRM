#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

// Function to read NFT data from a file
vector<pair<set<string>, NFT>> readNFTData(const string& filename) {
    vector<pair<set<string>, NFT>> nft_data;
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string trait;
            set<string> traits;
            while (getline(ss, trait, ',')) {
                traits.insert(trait);
            }
            // Assuming the last element is the NFT value
            double value = stod(trait);
            nft_data.push_back({traits, NFT(value)});
        }
        file.close();
    } else {
        cout << "Unable to open file: " << filename << endl;
    }
    return nft_data;
}

// Function to read user data from a file
vector<User> readUserData(const string& filename) {
    vector<User> user_data;
    ifstream file(filename);
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            stringstream ss(line);
            string id, friend_id;
            double beta_p, beta_c, gamma_p, impact;
            int breeding_quota;
            ss >> id >> beta_p >> beta_c >> gamma_p >> impact >> breeding_quota;
            User user(id, beta_p, beta_c, gamma_p, impact, breeding_quota);
            while (ss >> friend_id) {
                user.addFriend(friend_id);
            }
            user_data.push_back(user);
        }
        file.close();
    } else {
        cout << "Unable to open file: " << filename << endl;
    }
    return user_data;
}

// Function to read graph data from a file
Graph readGraphData(const string& nft_filename, const string& user_filename) {
    Graph graph;
    graph.NFTs = readNFTData(nft_filename);
    graph.users = readUserData(user_filename);
    // Assuming there are other parts of the graph data to be read
    return graph;
}

int main() {
    // Example usage
    string nft_filename = "nft_data.txt";
    string user_filename = "user_data.txt";
    Graph graph = readGraphData(nft_filename, user_filename);
    // Process graph data
    return 0;
}
