#include <bits/stdc++.h>
#include "Graph.h"
#include "NFTAlgorithm.h" // Including the header file for the NFT algorithm

using namespace std;

#define TEST_NUM 30
#define FORMAT setw(20) << right

int main(){
    cout << fixed;
    clock_t start, end;
    double total_time = 0;
    double profit_main_avg = 0, profit_profit_avg = 0, profit_IM_avg = 0;
    for(int i = 0; i < TEST_NUM; i++){
        start = clock();

        double profit_main, profit_profit, profit_IM;
        // Call functions from NFTAlgorithm.cpp
        profit_main = test_main();
        profit_profit = test_profit();
        profit_IM = test_IM();

        end = clock();

        profit_main_avg += profit_main/TEST_NUM;
        profit_profit_avg += profit_profit/TEST_NUM;
        profit_IM_avg += profit_IM/TEST_NUM;

        total_time += ((double)(end - start)) / CLOCKS_PER_SEC;
        cout << "test " << i << " finished!" << "used time:" << ((double)(end - start)) / CLOCKS_PER_SEC << "s \n";
        cout << "Profit(main):\t" << FORMAT << profit_main << '\n';
        cout << "Profit(profit):\t" << FORMAT << profit_profit << '\n';
        cout << "Profit(IM):\t" << FORMAT << profit_IM << '\n';

        if(i != TEST_NUM-1) cout << '\n';
    }
    cout << '\n'; 
    cout << "test finished!" << "used time:" << total_time << "s \n";;
    cout << "Profit(main):\t" << FORMAT << profit_main_avg << '\n';
    cout << "Profit(profit):\t" << FORMAT << profit_profit_avg << '\n';
    cout << "Profit(IM):\t" << FORMAT << profit_IM_avg << '\n';
}
