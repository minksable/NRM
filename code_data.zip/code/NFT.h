#pragma once
#include <bits/stdc++.h>
#include "User.h"
using namespace std;

#define ETA0 1.0
#define ETA1 1.0
#define ETA2 1.0


unordered_map<string, double> trait_rarity; // key: trait's name, value: rarity
class NFT{
public:
    set<string> traits; // traits of this NFT
    double overall_rarity = 0;
    int quantity;
    unordered_map<string, double> preference; // preference for each User
    

    NFT(set<string> st = {}){
        quantity = 1;
        traits = st;

        for(string trait: traits){
            overall_rarity += trait_rarity[trait];
        }
    }
    double get_assesment(){
        return exp(ETA0 + ETA1 * (1/quantity) + ETA2 * overall_rarity);
    }
    double get_offspring_assesment(){
        return exp(ETA0 + ETA1 * (1/(quantity+1)) + ETA2 * overall_rarity);
    }
    double user_valuation(User user){
        return preference[user.id] * get_assesment();
    }
    double user_valuation(string user_id){
        return preference[user_id] * get_assesment();
    }
    void add_quantity(){
        quantity++;
    }
    bool operator<(const NFT& rhs) const{
        return overall_rarity < rhs.overall_rarity;
    }
};