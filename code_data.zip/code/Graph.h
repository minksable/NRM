#pragma once
#include <bits/stdc++.h>
#include "NFT.h"
#include "User.h"

using namespace std;

// #define EDGE_FILE "./debug_dataset/edge.txt"
// #define NODE_FILE "./debug_dataset/node.txt"
#define EDGE_FILE "./2018-08/edge.csv"
#define NODE_FILE "./2018-08/node.csv"
#define NFT_FILE "./dataset2/nft.txt"
#define TRAIT_RARITY_FILE "./dataset2/trait_rarity.txt"

#define SEED_SET_SIZE 5
#define Q_K_MAX 5
#define OS_ASSESMENT_LOOP_NUM 100

#define SINGLE_TRAIT_INHERIT_PROBABILITY 0.5
#define DOUBLE_TRAIT_INHERIT_PROBABILITY 0.7

#define OS_BETA 1.0

#define DEBUG false

double RANDOM_NUM(){
    static std::random_device rd;
    static std::mt19937 mt(rd());
    static std::uniform_real_distribution<double> dist(0.0, 1.0);
    return dist(mt);
}

void print_set(set<string> s){
    cout << "{";
    for(auto it = s.begin(); it != s.end(); it++){
        cout << "\"" << *it << "\"";
        if(next(it) != s.end()){
            cout << ", ";
        }
    }
    cout << "}" << endl;
}


class Graph{
public:
    unordered_map<string, User> users; // map of user_id and user_infomation
    unordered_map<string, set<NFT>> user_owned_NFTs;
    map<set<string>, NFT> NFTs; // map of NFT trait combinations and NFT_infomation
    map<NFT, set<string>> seed_sets; // seed set for each NFT
    map<NFT, set<string>> buyer_sets; // buyer set for each NFT

    Graph(string edges_file = EDGE_FILE, string nodes_file = NODE_FILE, string nfts_file = NFT_FILE, string trait_rarity_file = TRAIT_RARITY_FILE){
        if(DEBUG)
            cout << "reading NFT file: " << nfts_file << endl;
        read_trait_rarity_file(trait_rarity_file);
        read_NFTs_file(nfts_file);
        if(DEBUG)
            cout << "NFT size: " << NFTs.size() << endl;

        if(DEBUG)
            cout << "reading nodes file: " << nodes_file << endl;
        read_nodes_file(nodes_file);
        if(DEBUG)
            cout << "node size: " << users.size() << endl;

        if(DEBUG)
            cout << "reading edges file: " << edges_file << endl;
        read_edges_file(edges_file);


        if(DEBUG)
            cout << "Graph created" << endl;
    }

    void read_nodes_file(string nodes_file){
        int count = 0;
        ifstream file(nodes_file);
        if(file.is_open()){
            while(!file.eof()){
                string id;
                file >> id;
                if(users.find(id) != users.end()){
                    cout<<"user : " << id << "duplicated!" << endl;
                    file.ignore(numeric_limits<streamsize>::max(), '\n'); // skip this line
                    continue;
                }
                users[id] = User(id);
                for(auto &NFTs_it: NFTs){
                    NFT &n = NFTs_it.second;
                    double w;
                    file >> w;
                    n.preference[id] = w;
                }

            }
            file.close();
        }
        else{
            cout << "Unable to open file: " << nodes_file << endl;
            exit(1);
        }
    }

    void read_edges_file(string edges_file){
        int count = 0;
        ifstream file(edges_file);
        if(file.is_open()){
            while(!file.eof()){
                string u1, u2;
                double w;
                file >> u1 >> u2 >> w;

                auto users_it1 = users.find(u1), users_it2 = users.find(u2);
                // create users if not exist
                if(users_it1 == users.end()){
                    if(!DEBUG)
                        cout << "user : " << u1 << "not found!" << endl;
                    continue;
                }
                if(users_it2 == users.end()){
                    if(!DEBUG)
                        cout << "user : " << u2 << "not found!" << endl;
                    continue;
                }

                // create edge
                users[u1].friends[u2] = w;
            }
            file.close();
        }
        else{
            cout << "Unable to open file: " << edges_file << endl;
            exit(1);
        }

    }

    
    void read_trait_rarity_file(string trait_rarity_file){
        ifstream file(trait_rarity_file);
        if(file.is_open()){
            while(!file.eof()){
                string trait;
                double rarity;
                file >> trait >> rarity;
                trait_rarity[trait] = rarity;
            }
        }
        else{
            cout << "Unable to open file: " << trait_rarity_file << endl;
            exit(1);
        }
    }
    void read_NFTs_file(string NFTs_file){
        ifstream file(NFTs_file);
        if(file.is_open()){
            while(!file.eof()){
                string line;
                while(getline(file, line)){
                    set<string> traits;
                    stringstream ss(line);
                    string trait;
                    while(getline(ss, trait, ' ')){
                        traits.insert(trait);
                    }
                    auto it = NFTs.find(traits);
                    if(it == NFTs.end()){
                        NFTs[traits] = NFT(traits);
                    }
                    else{
                        NFTs[traits].add_quantity();
                    }
                }
            }
            file.close();
        }
        else{
            cout << "Unable to open file: " << NFTs_file << endl;
            exit(1);
        }
    }

    void airdrop(){
        if(DEBUG)
            cout << "start airdrop" << endl;
        for(auto &it: seed_sets){
            NFT n = it.first;
            if(DEBUG){
                cout << "airdrop for NFT with traits : ";
                print_set(n.traits);
            }
            set<string> &S = it.second;
            set<string> active_users = get_affected_users(n, S, "");
            // get buyer set(active_users / S)
            auto &buyer_set = buyer_sets[n];
            set_difference(active_users.begin(), active_users.end(), S.begin(), S.end(), inserter(buyer_set, buyer_set.begin()));
            if(DEBUG){
                cout << "buyer set : ";
                print_set(buyer_set);
            }
            for(string user_id: buyer_set){
                user_owned_NFTs[user_id].insert(n);
            }
        }
        if(DEBUG)
            cout << "airdrop done" << endl;
    }

    double profit_func(){
        // TP(S_k, q_k), for k = 1, 2, ..., NFT_NUM
        pair<int, double> max_tp = {0, 0}; // first: q_k, second: max_tp
        for(auto it: NFTs){
            NFT &n = it.second;
            // get active users
            set<string> buyer_users_id = buyer_sets[n];

            if(DEBUG){
                cout << "start TP caculation for NFT with traits";
                print_set(n.traits);
            }

            // get TP of each NFT for different q_k
            // for(int q_k = 1; q_k <= Q_K_MAX; q_k++){
                int q_k = Q_K_MAX;
                double tp = TP(n, q_k, buyer_users_id);
                // record max tp and corresponding q_k
                if(tp > max_tp.second){
                    max_tp = {q_k, tp};
                }
            // }
            if(DEBUG)
                cout << "{q_k, max_tp} = " << "{" << max_tp.first << ", " << max_tp.second << "}" << endl;
        }

        // OS(S, Q)
        set<string> active_users_id;
        // set_union(seed_set.begin(), seed_set.end(), buyer_set.begin(), buyer_set.end(), inserter(active_users_id, active_users_id.begin()));
        return max_tp.second + OS();
    }

    double TP(NFT n, int q_k, set<string> &buyers){

        priority_queue<double, vector<double>, greater<double>> pq;
        for(auto user_id: buyers){
            pq.push(n.user_valuation(user_id));
            if(pq.size() > q_k){
                pq.pop();
            }
        }

        double tp = 0;
        while(!pq.empty()){
            double w = pq.top();
            pq.pop();
            tp += w;
        }
        // if(DEBUG)
        //     cout << "q_k=" << q_k << " : " << tp << '\n';
        return tp;
    }

    double OS(){
        double os = 0;
        for(auto &it: user_owned_NFTs){
            string user_id = it.first;
            set<NFT> &owned_NFTs = it.second;
            if(owned_NFTs.size() < 2) continue;
            os += offspring_assesment(owned_NFTs);
        }
        if(DEBUG)
            cout << "OS: " << os << endl;
        return os;
    }

    double offspring_assesment(set<NFT> &owned_NFTs){
        int sz = owned_NFTs.size() - 1;
        double assesment = 0;
        for(int i = 0; i < OS_ASSESMENT_LOOP_NUM; i++){
            // get two random NFTs
            int n1_idx = round(RANDOM_NUM() * sz);
            int n2_idx = round(RANDOM_NUM() * sz);
            while(n1_idx == n2_idx){
                n2_idx = round(RANDOM_NUM() * sz);
            }
            auto n1_it = owned_NFTs.begin(); advance(n1_it, n1_idx);
            auto n2_it = owned_NFTs.begin(); advance(n2_it, n2_idx);

            // get inherited traits from n1 and n2
            set<string> inherited_traits;
            // traits from n1 and n2 or only n1
            for(string trait: n1_it->traits){
                if(n2_it->traits.count(trait) && RANDOM_NUM() < DOUBLE_TRAIT_INHERIT_PROBABILITY){
                    // both NFT have this trait
                    inherited_traits.insert(trait);
                }
                else if(RANDOM_NUM() < SINGLE_TRAIT_INHERIT_PROBABILITY){
                    inherited_traits.insert(trait);
                }
            }
            // traits only from n2
            for(string trait: n2_it->traits){
                if(!n1_it->traits.count(trait) && RANDOM_NUM() < SINGLE_TRAIT_INHERIT_PROBABILITY){
                    inherited_traits.insert(trait);
                }
            }
            if(inherited_traits.size() == 0) continue; // no traits inherited
            // get assesment of offspring
            if(NFTs.count(inherited_traits) == 0){
                // new NFT
                assesment += NFT(inherited_traits).get_assesment();
            }
            else{
                assesment += NFTs[inherited_traits].get_offspring_assesment();
            }
        }
        return OS_BETA * assesment / OS_ASSESMENT_LOOP_NUM; // beta * average_assesment
    }

    /* IM Greedy */
    void findSeedSet_IM_greedy(){
        if(DEBUG)
            cout << "start findSeedSet(IM)" << endl;
        for(auto it: NFTs){
            if(DEBUG){
                cout << "start greedy(IM) for NFT with traits : ";
                print_set(it.second.traits);
            }
            NFT n = it.second;
            seed_sets[it.second] = IM_greedy(n, SEED_SET_SIZE);
            for(string user_id: seed_sets[it.second]){
                user_owned_NFTs[user_id].insert(n);
            }
        }
    }

    set<string> IM_greedy(NFT n, int k){
        set<string> S;
        for(int i = 0; i < k; i++){
            int max_affected_users = 0;
            string max_affected_user_id = "";
            for(auto it: users){
                string user_id = it.first;
                if(S.count(user_id)) continue;
                
                int count = get_affected_users(n, S, user_id).size();
                if(count > max_affected_users){
                    max_affected_users = count;
                    max_affected_user_id = user_id;
                }
            }
            S.insert(max_affected_user_id);
        }
        if(DEBUG){
            cout<<"seed set : ";
            print_set(S);
        }
        return S;
    }

    set<string> get_affected_users(NFT n, set<string> &S, string user_id){
        set<string> visited;
        queue<string> q;

        if(user_id != ""){
            q.push(user_id);
        }
        for(string s: S){
            q.push(s);
        }
        int count = 0;
        while(!q.empty()){
            string user_id = q.front(); q.pop();
            if(visited.count(user_id)) continue;
            visited.insert(user_id);
            User &user = users[user_id];
            if(user.friends.size() == 0) continue;
            for(auto it: user.friends){
                string friend_id = it.first;
                double w = it.second;
                double rand = RANDOM_NUM();
                if(rand < w){
                    q.push(friend_id);
                }
            }
        }

        return visited;
    }

    /* Profit Greedy */
    void findSeedSet_profit_greedy(){
        if(DEBUG)
            cout << "start findSeedSet(profit)" << endl;
        for(auto it: NFTs){
            NFT &n = it.second;
            if(DEBUG){
                cout << "start greedy(profit) for NFT with traits : ";
                print_set(n.traits);
            }
            seed_sets[n] = profit_greedy(n, SEED_SET_SIZE);
            for(string user_id: seed_sets[it.second]){
                user_owned_NFTs[user_id].insert(n);
            }
        }
    }

    set<string> profit_greedy(NFT n, int k){
        set<string> S;
        priority_queue<pair<double, string>, vector<pair<double, string>>, greater<pair<double, string>>> pq; // sorted by user_valuation
        for(auto it: users){
            string user_id = it.first;
            if(S.count(user_id)) continue;
            pq.push({n.user_valuation(user_id), user_id});
            if(pq.size() > k){
                pq.pop();
            }
        }
        
        while(!pq.empty()){
            string user_id = pq.top().second; pq.pop();
            S.insert(user_id);
        }
        if(DEBUG){
            cout<<"seed set : ";
            print_set(S);
        }
        return S;
    }

    /* TP greedy */
    void findSeedSet_TP_greedy(){
        if(DEBUG)
            cout << "start findSeedSet(main)" << endl;
        int q_k = 5;
        for(auto it: NFTs){
            NFT &n = it.second;
            if(DEBUG){
                cout << "start greedy(main) for NFT with traits : ";
                print_set(n.traits);
            }
            seed_sets[n] = TP_greedy(n, SEED_SET_SIZE, q_k);
            for(string user_id: seed_sets[n]){
                user_owned_NFTs[user_id].insert(n);
            }
        }
    }
    set<string> TP_greedy(NFT n, int k, int q_k){
        set<string> S;
        for(int i = 0; i < k; i++){
            double max_tp = 0;
            string max_tp_user_id = "";
            for(auto it: users){
                string user_id = it.first;
                if(S.count(user_id)) continue;
                set<string> buyer_set; // simulated buyer set

                set<string> affected_users = get_affected_users(n, S, user_id);
                set_difference(affected_users.begin(), affected_users.end(), S.begin(), S.end(), inserter(buyer_set, buyer_set.begin()));

                // get first q_k users with highest valuation
                priority_queue<double, vector<double>, greater<double>> pq;
                for(auto user_id: buyer_set){
                    pq.push(n.user_valuation(user_id));
                    if(pq.size() > q_k){
                        pq.pop();
                    }
                }

                // calculate tp(S_k, q_k)
                double tp = 0;
                while(!pq.empty()){
                    double w = pq.top();
                    pq.pop();
                    tp += w;
                }

                // record max tp and corresponding user_id
                if(tp > max_tp){
                    max_tp = tp;
                    max_tp_user_id = user_id;
                }
            }
            S.insert(max_tp_user_id);
        }
        if(DEBUG){
            cout<<"seed set : ";
            print_set(S);
        }
        return S;
    }
};