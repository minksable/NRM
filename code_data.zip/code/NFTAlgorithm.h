#pragma once

// Declarations of functions for NFT algorithm
double test_main();
double test_profit();
double test_IM();
// Add declarations for any other functions you'll implement in "NFTAlgorithm.cpp"
