#include "NFTAlgorithm.h"
#include "Graph.h"

// Function to identify users purchasing at least one treasure as nThrees
set<string> findNThrees(const Graph& graph, const set<NFT>& treasures) {
    set<string> nThrees;
    for (const auto& user : graph.users) {
        const string& user_id = user.first;
        const unordered_map<string, double>& user_owned_NFTs = graph.user_owned_NFTs[user_id];
        for (const auto& nft_entry : user_owned_NFTs) {
            const NFT& nft = nft_entry.first;
            if (treasures.count(nft)) {
                nThrees.insert(user_id);
                break;
            }
        }
    }
    return nThrees;
}
